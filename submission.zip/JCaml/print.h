#ifndef PRINT_H
#define PRINT_H

#include "values.h"

int print_result(val_t);

#endif
